using System;

namespace Abstraction.Abstractclass
{
    public abstract class AlatMusik
    {
        public abstract void Bunyi();
    }
}
