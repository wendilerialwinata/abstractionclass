using System;

namespace Abstraction.Abstractclass
{
    public class Piano : AlatMusik
    {
        public override void Bunyi()
        {
            Console.WriteLine("Untuk Menghasilkan Bunyi Gitar Yang Baik yaitu dengan cara ditekan fretnya");
            Console.WriteLine("Piano Merupakan Instrumen yang sangat penting untuk menghasilkan musik yang sentimental");
        }
    }
}