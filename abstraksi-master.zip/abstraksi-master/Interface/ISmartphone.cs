using System;

namespace Abstraction.Interface
{
    public interface ISmartphone
    {
        void Merk();
    }
}
